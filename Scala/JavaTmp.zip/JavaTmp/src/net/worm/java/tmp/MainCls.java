/**
 * 
 */
package net.worm.java.tmp;


/**
 * @author worm
 * 
 */
public class MainCls
{
    public static void main(String[] args) throws Exception
    {
        Func<Byte> bfc = new ByteFunc();
        Brainfuck<Byte> bf = new Brainfuck<Byte>(bfc);
        bf.execute(">+++++++++[<++++++++>-]<.>+++++++[<++"
                + "++>-]<+.+++++++..+++.[-]>++++++++[<++++>-]"
                + "<.#>+++++++++++[<+++++>-]<.>++++++++[<++"
                + "+>-]<.+++.------.--------.[-]>++++++++[<++++>"
                + "-]<+.[-]++++++++++.");
    }

}