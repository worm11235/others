package net.worm.java.tmp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

class Brainfuck<T>
{

    private Func<T> func;

    //执行代码
    private String prog;

    //循环开始到结束的位置映射
    private Map<Integer, Integer> open2close;

    //循环结束到开始的位置映射
    private Map<Integer, Integer> close2open;

    public Brainfuck(Func<T> f)
    {
        func = f;
    }

    /**
     * 查找并记录语句中的“[]”对。
     * @param pos
     * @param stack
     * @param o2c
     * @return
     */
    public Map<Integer, Integer> braceMatcher(int pos, List<Integer> stack,
            Map<Integer, Integer> o2c)
    {
        if (pos == prog.length())
            return o2c;
        else
        {
            switch (prog.charAt(pos))
            {
                case '[':
                
                    {
                        stack.add(0, pos);
                        return braceMatcher(pos + 1, stack, o2c);
                    }
                case ']':
                {
                    o2c.put(stack.get(0), pos);
                    return braceMatcher(pos + 1,
                            stack.subList(1, stack.size()), o2c);
                }
                default:
                    return braceMatcher(pos + 1, stack, o2c);
            }
        }

    }

    /**
     * 逻辑跳转语句执行器。
     * @param pos
     * @param tape
     */
    public void ex(int pos, Tape<T> tape)
    {
        if (pos < prog.length())
        {
            int np = pos + 1;
            switch (prog.charAt(pos))
            {
                case '[':
                    if (tape.isZero())
                        np = open2close.get(pos);
                    break;
                case ']':
                    if (!tape.isZero())
                        np = close2open.get(pos);
                    break;
                default:
                    np = pos + 1;
            }

            ex(np, tape.execute(prog.charAt(pos)));
        }
    }

    /**
     * 解释执行输入代码P
     * @param p
     */
    public void execute(String p)
    {
        prog = p.replaceAll("[^\\+\\-\\[\\]\\.\\,\\>\\<]", "");

        open2close = braceMatcher(0, new ArrayList<Integer>(), new HashMap<Integer, Integer>());
        close2open = new HashMap<Integer, Integer>();
        for (Entry<Integer, Integer> et : open2close.entrySet())
        {
            close2open.put(et.getValue(), et.getKey());
        }

        System.out.println("---running---");
        Tape<T> tape = new Tape<T>(new ArrayList<T>(), func.getZero(), new ArrayList<T>(), func);
        ex(0, tape);
        System.out.println("\n---done---");
    }
}