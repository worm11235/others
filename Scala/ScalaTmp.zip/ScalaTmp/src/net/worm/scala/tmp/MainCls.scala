/**
  * file  :MainCls.scala
  * auther:worm
  * date  :2014年2月22日
  */
package net.worm.scala.tmp

import scala.beans.BeanProperty

/**
  * @author worm
  *
  */
class NewType(val v: Int, var t: String) {
}
abstract class Tree
case class Sum(r: Tree, l: Tree) extends Tree {
    override def toString(): String = {
        return "";
    }
}
case class Var(v: String) extends Tree
case class Const(c: Int) extends Tree

object MainCls {
    
    def switch(v: Any)(body: Any => Unit) = v match {
            case _ => body
    }
    
    var sv = 12;
    
    
    switch (sv)
    {
        case x: Int if x == 12 => println("hello world")
        case _=> Unit;
    }
    
    trait IValuable {
        def getValue: Double
    }
    
    trait ICalculable extends IValuable {
        def +(n: ICalculable): ICalculable
        def minus(n: ICalculable): ICalculable
        def multiple(n: ICalculable): ICalculable
        def divide(n: ICalculable): ICalculable
    }
    class Num(val v: Double, val d: Int = 10) extends ICalculable {
        
        override def getValue: Double = {return v.toInt}
        
        override def +(n: ICalculable): Num = {
            new Num(v + n);
        }
        
        override def minus(n: ICalculable): Num = {
            new Num(v - n)
        }
        
        def divide(n: ICalculable): Num = {
            new Num(v / n)
        }
        
        def multiple(n: ICalculable): Num = {
            new Num(v * n)
        }
        
        override def toString: String = "v=" + v + ", d=" + d
    }
    
    class StrNum(override val v: Double, val f: Double) extends Num(v + 10) {
        
        override def getValue: Double = (return v+f)
        
        override def +(n: ICalculable): Num = n match {
            case s: StrNum => new StrNum(v + s.v, f + s.f);
            case _ => new Num(this.getValue + n.getValue);
        }
        
        override def toString: String = "s=" + v + ", f=" + f + ", super:" + super.getValue;
    }
    
    implicit def ical2Value(ic: ICalculable): Double = ic.getValue
    
    implicit def db2Num(v: Double): Num = new Num(v)
    
    implicit def num2Str(v: Num): String = 10.toString
    
    var n:ICalculable = new StrNum(2, 4)
    
    n.`+`(23)
    
    val ++?><-=:  = 12
    println("test: " + ++?><-=:)
    
    var sint = 12
    
    var set = for (i <- 0 to 12;
         j <- i to 100 if i * j == 125) yield Pair(i, j)
    set.foreach{case (i, j)=>println("i=" + i + ", j=" + j); }
    
    println(n + 12)
    println(n.minus(12))
    println(n.divide(12))
    println(n.multiple(12))

    type Environment = String => Int

    def eval(t: Tree, e: Environment): Int = t match {
        case Sum(r, l) => eval(r, e) + eval(l, e)
        case Var(v) => e(v)
        case Const(c) => c
    }

    def derive(t: Tree, s: String): Tree = t match {
        case Sum(r, l) => Sum(derive(r, s), derive(l, s))
        case Var(v) if (v == s) => Const(1)
        case _ => Const(0)
    }

    def matchTest(x: Any): Any = x match {
        case 1 => "one"
        case "two" => 2
        case y: Int if y > 10 => "scala.Int: " + y
        case _ => x.toString()
    }
    
    println(matchTest(123));

    object Twice {
        def apply(x: Int): Int = x * 2
        def unapply(z: Int): Option[Int] = if (z % 2 == 0) Some(z / 2) else None
    }

    object 你好asd_&+-/ extends Application {
        val x = Twice(21)
        x match { case Twice(n) => Console.println(n) } // prints 21
    }

    def add(a: Int) = (b: Int) => {(c: Int) => (a + b + c)}
    
    var ad = add _;
    var dal: Any = ad;
    
    def multMet[T1, T2] (a: T1, b: T2): String = {
        return a + b.toString
    }

    val del = (a: Int) => a * 9;
    val func = () => println("Out side codes.");

    /*def whileLoop(cond: => Boolean)(body: => Unit): Unit =
        if (cond) {
            body
            whileLoop(cond)(body)
        }
    
    var i = 10
    whileLoop({i > 0}) {
        println(i)
        i -= 1
    }*/

    def main(args: Array[String]): Unit = {
        val exp: Tree = Sum(Sum(Var("x"), Var("x")), Sum(Const(7), Var("y")))
        val env: Environment = { case "x" => 5 case "y" => 7 }

        println("Expression: $exp" + exp)
        println("Evaluation with x=5, y=7: " + eval(exp, env))
        println("Derivative relative to x: " + eval(derive(exp, "x"), env))
        println("Derivative relative to y: " + eval(derive(exp, "y"), env))
        //return
        val start = System.currentTimeMillis();
        var totle = 0; var i = 0;
        //start = 9
        while ({i < 100000}) { i += 1; totle += i; };
        var end = System.currentTimeMillis();
        println(end - start)
        var m: Int => Int = add(1)(3);
        println(del(m(3)))
        func()
        val xml =
            <xml>
        		<data>hello</data>
        		<start>{start}</start>
        		<end>{end}</end>
        	</xml>
        println(xml)
        
    }

}