package net.worm.java.tmp;

import java.util.ArrayList;
import java.util.List;

/**
 * 用来表示状态机的存储设备。
 * 
 * @author worm
 *
 * @param <T>
 */
class Tape<T>
{
    //当前指针指向的单元
    private T cell;
    
    //执行器
    private Func<T> func;
    
    //当前单元左侧的存储空间
    private List<T> left;
    
    //当前单元右侧的存储空间
    private List<T> right;

    /**
     * 
     * @param l
     * @param c
     * @param r
     * @param func
     */
    public Tape(List<T> l, T c, List<T> r, Func<T> func)
    {
        cell = c;
        left = l;
        right = r;
        this.func = func;
    }

    private T headOf(List<T> list)
    {
        if (list.isEmpty())
            return func.getZero();
        else
            return list.get(0);
    }

    private List<T> tailOf(List<T> list)
    {
        if (list.isEmpty())
            return new ArrayList<T>();
        else
        {
            return list.subList(1, left.size());
        }
    }

    /**
     * 判断当前指针指向的单元内值是否为零。
     * @return
     */
    public boolean isZero()
    {
        return cell == func.getZero();
    }

    /**
     * 执行器。
     * @param ch
     * @return
     */
    public Tape<T> execute(char ch)
    {
        switch (ch)
        {
            case '+':
                return new Tape<T>(left, func.inc(cell), right, func);
            case '-':
                return new Tape<T>(left, func.dec(cell), right, func);
            case '<':
            {
                right.add(0, cell);
                return new Tape<T>(tailOf(left),
                        headOf(left), right, func);
            }
            case '>':
            {
                left.add(0, cell);
                return new Tape<T>(left, headOf(right),
                        tailOf(right), func);
            }
            case '.':
                func.out(cell);
                return this;
            case ',':
                return new Tape<T>(left, func.in(), right, func);
            case '[':
            case ']':
                return this;
            default:
                throw new RuntimeException("Unexpected token: " + ch);
        }
    }
}