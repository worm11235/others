/**
 * 
 */
package net.worm.java.tmp;


/**
 * @author worm
 * 
 */
public final class Executor
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        Func<Byte> bfc = new ByteFunc();
        Brainfuck<Byte> bf = new Brainfuck<Byte>(bfc);
        bf.execute(",-------------[-------------------.,-------------]");

    }

}
