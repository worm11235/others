/**
  *
  */
package net.worm.scala.tmp

import scala.util.parsing.combinator.syntactical.StandardTokenParsers

/**
  * @author worm
  *
  */
object arithmeticParsers extends StandardTokenParsers {   

  class Expr
  case class BinOp(op: String, l: Expr, r: Expr) extends Expr
  case class Num(n: Int) extends Expr

  lexical.delimiters ++= List("(", ")", "+", "-", "*", "/")

  val reduceList: Expr ~ List[String ~ Expr] => Expr = {
    case i ~ ps => (i /: ps)(reduce) 
  }

  def reduce(l: Expr, r: String ~ Expr) = BinOp(r._1, l, r._2)
  def mkNum(s: String) = Num(s.toInt)

  def expr  : Parser[Expr] = term ~ rep ("+" ~ term | "-" ~ term) ^^ reduceList
  def term  : Parser[Expr] = factor ~ rep ("*" ~ factor | "/" ~ factor) ^^ reduceList
  def factor: Parser[Expr] = "(" ~> expr <~ ")" | numericLit ^^ ((s: String) => Num(s.toInt))

  def main(args: Array[String]) {
    val input = args.mkString(" ")
    val parse = phrase(expr)
    val tokens = new lexical.Scanner(input)
    println(input)
    println(parse(tokens))
  }
}
