package net.worm.java.tmp;

/**
 * 
 * @author worm
 * 
 */
interface Func<T>
{
    T getZero();

    void setZero(T t);

    T inc(T t);

    T dec(T t);

    T in();

    void out(T t);
}