package net.worm.java.tmp;

import java.io.IOException;

/**
 * 
 * @author worm
 *
 */
class ByteFunc implements Func<Byte>
{
    private Byte zero = 0;

    public Byte getZero()
    {
        return zero;
    }

    public void setZero(Byte t)
    {
        zero = t;
    }

    public Byte inc(Byte t)
    {
        if (null == t)
            return t;
        return (byte) ((t + 1) & 0xFF);
    }

    public Byte dec(Byte t)
    {
        if (null == t)
            return t;
        return (byte) ((t - 1) & 0xFF);
    }

    public Byte in()
    {
        try
        {
            byte b = (byte) System.in.read();
            return b;
        } catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public void out(Byte t)
    {
        if (null == t)
            return;
        char c = (char) t.byteValue();
        System.out.print(c);
    }
}